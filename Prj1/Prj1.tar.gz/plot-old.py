import os
import matplotlib.pyplot as plt

# Configurations
matrix_sizes = [100, 128, 200, 256]
stat_labels = [
    "simSeconds",
    "simTicks",
    "simInsts",
    "simOps",
    "system.cpu.cpi",
    "system.cpu.ipc",
    "system.cpu.dcache.demandHits::total",
    "system.cpu.dcache.demandMisses::total",
    "system.cpu.dcache.demandAccesses::total",
    "system.cpu.icache.demandHits::total",
    "system.cpu.icache.demandMisses::total",
    "system.cpu.icache.demandAccesses::total"
]
# stat_colors = ['blue']*6 + ['gold']*3 + ['red']*3

stat_colors = [
    'blue',    # 1st color
    'green',   # 2nd color
    'red',     # 3rd color
    'cyan',    # 4th color
    'magenta', # 5th color
    'yellow',  # 6th color
    'black',   # 7th color
    'orange',  # 8th color
    'purple',  # 9th color
    'brown',   # 10th color
    'pink',    # 11th color
    'gray'     # 12th color
]

# File parsing: lines to extract (0-indexed)
stat_line_nums = [2, 3, 9, 10, 16, 17, 115, 119, 127, 250, 254, 262]

# Load stats from a file
def load_stats(stats_file_path):
    stats = {}
    if not os.path.exists(stats_file_path):
        return stats

    with open(stats_file_path, 'r') as f:
        for line in f:
            if line.strip().startswith("#") or line.strip() == "":
                continue
            parts = line.strip().split()
            if len(parts) >= 2:
                key = parts[0]
                try:
                    value = float(parts[1])
                except ValueError:
                    continue  # skip if conversion fails
                stats[key] = value
                # print(f"Loaded {key}: {value} from {stats_file_path}")
    return stats


# Collect all data in a nested dict: [matrix_size][block_size or 'base'] = stat_values
data_by_matrix = {size: {} for size in matrix_sizes}
block_sizes_map = {}

for matrix_size in matrix_sizes:
    # Base
    base_path = f"l1_base_{matrix_size}/stats.txt"
    stats = load_stats(base_path)
    if stats:
        data_by_matrix[matrix_size]['base'] = stats
    print(f"Matrix size {matrix_size}: base stats loaded")

    # Blocked
    block = 16
    blocks_used = []
    while block <= matrix_size:
        path = f"l1_block_{matrix_size}_{block}/stats.txt"
        stats = load_stats(path)
        if stats:
            data_by_matrix[matrix_size][block] = stats
            blocks_used.append(block)

        if block == matrix_size:
            break
        block *= 2
        if block > matrix_size:
            block = matrix_size
    block_sizes_map[matrix_size] = blocks_used
    print(f"Matrix size {matrix_size}: blocks used = {blocks_used}")

# 1. Plot per matrix size (x-axis: base + block sizes)
for matrix_size, stats_dict in data_by_matrix.items():
    # print(f"Matrix size {matrix_size}: stats_dict = {stats_dict}")
    plt.figure(figsize=(16, 8))
    keys = ['base'] + block_sizes_map[matrix_size]
    x = list(range(len(keys)))

    for i, label in enumerate(stat_labels):
        y = [stats_dict[k].get(label, 0) for k in keys if k in stats_dict]
        plt.plot(x[:len(y)], y, label=label, color=stat_colors[i])
        print(f"Matrix size {matrix_size}: label = {label} values = {y}")
        # print(f"Matrix size {matrix_size}: {label} values = {y} keys = {keys[:len(y)]}")

    plt.xticks(x, keys)
    plt.xlabel("Block Size (or base)")
    plt.ylabel("Value")
    plt.title(f"Statistics for matrix size {matrix_size}")
    plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
    plt.tight_layout()
    plt.grid(True)
    plt.savefig(f"plot_matrix_{matrix_size}.png")
    plt.close()

# 2. Plot per block size (x-axis: matrix sizes)
all_block_sizes = sorted(set(b for blocks in block_sizes_map.values() for b in blocks))
for block_size in all_block_sizes:
    plt.figure(figsize=(16, 8))
    x = []
    data = [[] for _ in stat_labels]
    for matrix_size in matrix_sizes:
        stat = data_by_matrix[matrix_size].get(block_size)
        if stat:
            x.append(matrix_size)
            for i in range(len(stat_labels)):
                data[i].append(stat.get(stat_labels[i], 0))
    for i in range(len(stat_labels)):
        plt.plot(x, data[i], label=stat_labels[i], color=stat_colors[i])
    plt.xlabel("Matrix Size")
    plt.ylabel("Value")
    plt.title(f"Statistics for block size {block_size}")
    plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
    plt.tight_layout()
    plt.grid(True)
    plt.savefig(f"plot_block_{block_size}.png")
    plt.close()

# 3. Plot for matmul-base only (x-axis: matrix sizes)
plt.figure(figsize=(16, 8))
x = []
data = [[] for _ in stat_labels]
for matrix_size in matrix_sizes:
    stat = data_by_matrix[matrix_size].get("base")
    if stat:
        x.append(matrix_size)
        for i in range(len(stat_labels)):
            data[i].append(stat.get(stat_labels[i], 0))
for i in range(len(stat_labels)):
    plt.plot(x, data[i], label=stat_labels[i], color=stat_colors[i])
plt.xlabel("Matrix Size")
plt.ylabel("Value")
plt.title("Statistics for matmul-base")
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
plt.tight_layout()
plt.grid(True)
plt.savefig("plot_base_all.png")
plt.close()

"Plots generated: one per matrix size, one per block size, and one for matmul-base."
